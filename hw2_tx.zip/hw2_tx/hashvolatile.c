#include "hashvolatile.h"

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define INITIAL_CAPACITY 16
#define FNV_OFFSET 14695981039346656037UL
#define FNV_PRIME 1099511628211UL

typedef struct{
    int isval;
    char *key; 
    char *value;
}ht_entry;

struct ht {
    ht_entry* entries;
    size_t capacity;
    size_t length;
};

static uint64_t hash_key(char* key) {
    uint64_t hash = FNV_OFFSET;
    for (char* p = key; *p; p++) {
        hash ^= (uint64_t)(unsigned char)(*p);
        hash *= FNV_PRIME;
    }
    return hash;
}

ht* ht_create() {
    ht* table = (ht*)malloc(sizeof(ht));
    if (table == NULL) {
        return NULL;
    }
    table->length = 0;
    table->capacity = INITIAL_CAPACITY;

    table->entries = malloc(table->capacity*sizeof(ht_entry));
    if(table->entries == NULL) {
        free(table);
        return NULL;
    }
    return table;
}

void ht_destroy(ht* table) {
    for (size_t i = 0; i < table->capacity; i++) {
        if (table->entries[i].key != NULL) {
            free((void*)table->entries[i].key);
        }
    }

    free(table->entries);
    free(table);
}

void* ht_get(ht* table, const char* key) {
    uint64_t hash = hash_key(key);
    size_t index = (size_t)(hash & (uint64_t)(table->capacity - 1));

    while (table->entries[index].key != NULL) {
        if (strcmp(key, table->entries[index].key) == 0) {
            return table->entries[index].value;
        }

        index++;
        if (index >= table->capacity) {
            index = 0;
        }
    }
    return NULL;
}

char* ht_set_entry(ht_entry* entries, size_t capacity, char* key, char* value, size_t* plength) {
    uint64_t hash = hash_key(key);
    size_t index = (size_t)(hash & (uint64_t)(capacity - 1));
    
    if(key == NULL){
        printf("Key invalid\n");
        return NULL;
    }

    while(entries[index].key != NULL) {
        if(strcmp(key, entries[index].key) == 0) {
            entries[index].value = value;
            return entries[index].key;
        }

        index++;
        if(index >= capacity) {
            index = 0;
        }
    }

    if (plength != NULL) {
        (*plength)++;
    }
    entries[index].key = key;
    entries[index].value = value;
    return key;
}

bool ht_expand(ht* table) {
    size_t new_capacity = table->capacity * 2;
    if (new_capacity < table->capacity) {
        return false;
    }
    ht_entry* new_entries = malloc(new_capacity*sizeof(ht_entry));
    if (new_entries == NULL) {
        return false;
    }

    for (size_t i = 0; i < table->capacity; i++) {
        ht_entry entry = table->entries[i];
        if (entry.key != NULL) {
            ht_set_entry(new_entries, new_capacity, entry.key, entry.value, NULL);
        }
    }

    free(table->entries);
    table->entries = new_entries;
    table->capacity = new_capacity;
    return true;
}

char* ht_set(ht* table, const char* key, void* value) {
    if(value == NULL) {
        return NULL;
    }
    if(table->length >= table->capacity / 2) {
        if(!ht_expand(table)) {
            printf("couldn't expand table\n");
            return NULL;
        }
    }

    return ht_set_entry(table->entries, table->capacity, key, value, &table->length);
}

size_t ht_length(ht* table) {
    return table->length;
}

hti ht_iterator(ht* table){
    hti it;
    it.tableitr = table;
    it.indexitr = 0;
    return it;
}

bool ht_next(hti* it){
    ht* table = it->tableitr;
    while (it->indexitr < table->capacity) {
        size_t i = it->indexitr;
        it->indexitr++;
        if (table->entries[i].key != NULL) {
            ht_entry entry = table->entries[i];
            it->key = entry.key;
            it->value = entry.value;
            return true;
        }
    }
    return false;
}

void printhash(ht *htable){        
    /*hti it = ht_iterator(htable);
    while (ht_next(&it)) {
        printf("%s %s\n", it.key, it.value);
        //free(it.value);
    }*/
    int idx = 0;
    char *str = NULL;
    while(idx < htable->capacity) {
        if(htable->entries[idx].key != str){
            printf("Key:%s\t Value:%s\n", htable->entries[idx].key, htable->entries[idx].value);
            /*if(htable->entries[idx].key != NULL) {
                printf("%s %s\n", htable->entries[idx].key, htable->entries[idx].value);
                ht_entry entry = htable->entries[idx];
                printf("key: %s\t val: %s\n", entry.key, entry.value);
            }
            else{
                printf("NULL\n");
                //break;
            }*/ 
        }
        idx++;      
    }
}

int main(int argc, char *argv[]){
    int ch;
    char key[1000], val[1000], *gval;
    ht *htable = ht_create();
    if(htable == NULL){
        printf("error creating hashtable\n");
        return 0;     
    }

    while(1){
        printf("1-insert 2-retrieve 3-print hashtable 4-quit\n");
        scanf("%d,%s",&ch,key);
        if(ch==1){
            printf("enter key value\n");
            scanf("%s", key);
            scanf("%s", val);
            printf("key %s val %s\n",key,val);
            ht_set(htable, key, val);
        }
        else if(ch==2){
            printf("enter key\n");
            scanf("%s", key);
            gval = ht_get(htable, key);
            if(gval == NULL){
                printf("entry not found\n");
            }
            else{
                printf("key: %s\t value: %s\n", key, gval);
            }
        }
        else if(ch==3){
            printhash(htable);
        }
        else if(ch==4){
            //add persist code here
            break;
        }
        else{
            printf("Invalid command\n");
        }
    }

    return 1;
}
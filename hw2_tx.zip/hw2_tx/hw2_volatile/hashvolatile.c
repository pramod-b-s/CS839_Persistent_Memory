#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define INITIAL_CAPACITY 256
#define FNV_OFFSET 14695981039346656037UL
#define FNV_PRIME 1099511628211UL

typedef struct{
    int isval;
    int idx;
    char key[1000]; 
    char value[64000];
}ht_entry;

struct ht {
    ht_entry* entries;
    int capacity;
    int length;
};
typedef struct ht ht;

static uint64_t hash_key(char* key) {
    uint64_t hash = FNV_OFFSET;
    for (char* p = key; *p; p++) {
        hash ^= (uint64_t)(unsigned char)(*p);
        hash *= FNV_PRIME;
    }
    return hash;
}

ht* ht_create() {
    ht* table = (ht*)malloc(sizeof(ht));
    if (table == NULL) {
        return NULL;
    }
    table->length = 0;
    table->capacity = INITIAL_CAPACITY;

    table->entries = malloc(table->capacity*sizeof(ht_entry));
    if(table->entries == NULL) {
        free(table);
        return NULL;
    }
    return table;
}

void ht_destroy(ht* table) {
    for (int i = 0; i < table->capacity; i++) {
        if (table->entries[i].key != NULL) {
            free((void*)table->entries[i].key);
        }
    }

    free(table->entries);
    free(table);
}

void ht_get(ht* table, char* key) {
    uint64_t hash = hash_key(key);
    int index = (int)(hash & (uint64_t)(table->capacity - 1));

    while (table->entries[index].isval != 0) {
        if (strcmp(key, table->entries[index].key) == 0) {
            printf("idx: %d\t key: %s\t key1: %s\t value: %s\n", index, key, table->entries[index].key, table->entries[index].value);
            return;
        }
        else{
            index++;
        }

        if(index >= table->capacity) {
            index = 0;
        }
    }
    printf("entry not found\n");
}

int ht_set_entry(ht_entry* entries, int capacity, char* key, char* value, int *plength) {
    uint64_t hash = hash_key(key);
    int index = (int)(hash & (uint64_t)(capacity - 1));
    
    if(key == NULL){
        printf("Key invalid\n");
        return NULL;
    }

    while(entries[index].isval != 0) {
        if(strcmp(key, entries[index].key) == 0) {
            strcpy(entries[index].value, value);
            return 0;
        }

        index++;
        if(index >= capacity) {
            index = 0;
        }
    }
    
    (*plength)++;    
    entries[index].isval = 1;
    entries[index].idx = index;
    strcpy(entries[index].key, key);
    strcpy(entries[index].value, value);
    return 1;
}

bool ht_expand(ht* table) {
    int new_capacity = table->capacity * 2;
    ht_entry* new_entries = malloc(new_capacity*sizeof(ht_entry));
    if(new_entries == NULL) {
        printf("memory allocation failed!\n");
        return false;
    }

    for(int i = 0; i < table->capacity; i++) {
        ht_entry entry = table->entries[i];
        ht_set_entry(new_entries, new_capacity, entry.key, entry.value, NULL);        
    }

    free(table->entries);
    table->entries = new_entries;
    table->capacity = new_capacity;
    return true;
}

int ht_set(ht* table, char* key, char* value) {
    if(value == NULL) {
        return NULL;
    }
    if(table->length >= table->capacity / 2) {
        if(!ht_expand(table)) {
            printf("couldn't expand table\n");
            return 0;
        }
    }

    return ht_set_entry(table->entries, table->capacity, key, value, &table->length);
}

void printhash(ht *htable){        
    int idx = 0;
    char *str = NULL;
    while(idx < htable->capacity) {
        if(htable->entries[idx].isval){
            printf("Key:%s\t Value:%s\n", htable->entries[idx].key, htable->entries[idx].value);
        }
        /*else{
            printf("Key:%s\t Value:%s\n", htable->entries[idx].key, htable->entries[idx].value);
        }*/
        idx++;      
    }
}

int main(int argc, char *argv[]){
    int ch;
    char key[1000], val[1000], *gval;    
    ht *htable = ht_create();
    if(htable == NULL){
        printf("error creating hashtable\n");
        return 0;     
    }

    while(1){
        printf("1-insert 2-retrieve 3-print hashtable 4-quit\n");
        scanf("%d",&ch);
        if(ch==1){
            printf("enter key:\t");
            scanf("%s", key);
            printf("enter value:\t");
            scanf("%s", val);            
            ht_set(htable, key, val);
            printf("key %s val %s stored!\n",key,val);
        }
        else if(ch==2){
            printf("enter key\t");
            scanf("%s", key);
            ht_get(htable, key);            
        }
        else if(ch==3){
            printhash(htable);
        }
        else if(ch==4){
            //add persist code here
            break;
        }
        else{
            printf("Invalid command\n");
        }
    }

    return 1;
}
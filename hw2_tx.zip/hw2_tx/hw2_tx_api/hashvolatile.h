#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <libpmemobj.h>

typedef struct ht_entry{
    int isval;
    int idx;
    uint64_t key; 
    char value[64000];
} ht_entry;

typedef struct pmem_ht{
    PMEMoid *entries;
    int capacity;
    int length;
} pmem_ht;
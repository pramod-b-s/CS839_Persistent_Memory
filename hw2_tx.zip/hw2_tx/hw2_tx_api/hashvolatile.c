#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <libpmemobj.h>

#define LAYOUT_NAME "my_persistent_hash"
#define FILE_NAME "myhash"
#define MAX_VAL_LEN 64000

#define INITIAL_CAPACITY 256 

int currcapacity;

TOID_DECLARE(struct ht_entry, 2);

typedef struct ht_entry{
    int isval;
    int idx;
    uint64_t key; 
    char value[64000];
} ht_entry;

struct pmem_ht{
    TOID(ht_entry) entries[45];
    int capacity;
    int length;
};
typedef struct pmem_ht pmem_ht;

POBJ_LAYOUT_BEGIN(hashcalc);
POBJ_LAYOUT_ROOT(hashcalc, pmem_ht);
POBJ_LAYOUT_TOID(hashcalc, ht_entry);
POBJ_LAYOUT_END(hashcalc);

static int hash_key(uint64_t key, int capacity){
    return (key);
}

void ht_create(PMEMobjpool *pop) {
    TOID(pmem_ht) root = POBJ_ROOT(pop, pmem_ht);
    int i,n;
    printf("hash create\n");

    TX_BEGIN(pop) {
        TX_ADD(root);
        root = TX_ZNEW(pmem_ht);
        D_RW(root)->capacity = INITIAL_CAPACITY;
        D_RW(root)->length = 0;
        printf("%d %d\n",D_RO(root)->capacity,D_RO(root)->length);

        n=D_RO(root)->capacity;
        D_RW(root)->entries = TX_ZALLOC(ht_entry, sizeof(ht_entry)*INITIAL_CAPACITY);
        /*for(i=0;i<n;i++){
            D_RW(D_RW(root)->entries[i])->key = 0;
            D_RW(D_RW(root)->entries[i])->isval = 0;
        }*/
    } TX_END    
}

void ht_get(PMEMobjpool *pop, uint64_t key) {
    int i,j,n,index = hash_key(key, currcapacity);
    TOID(pmem_ht) root = POBJ_ROOT(pop, pmem_ht);
    printf("Read from pers mmy\n");
    
    TX_BEGIN(pop) {
        TX_ADD(root);
        printf("%d %d\n",D_RO(root)->length,D_RO(root)->capacity);
        
        n = D_RO(root)->capacity;
        while(D_RO(D_RO(root)->entries[index])->isval != 0) {  
            if(key == D_RO(D_RO(root)->entries[index])->key) {
                printf("idx: %d\t key: %lu\t value: %s\n", index, 
                    D_RO((D_RO(root)->entries[index]))->key, D_RO((D_RO(root)->entries[index]))->value);
                return;
            }
            else{
                index++;
            }

            if(index >= D_RO(root)->capacity) {
                index = 0;
            }
        }
        printf("entry not found\n");
    } TX_END
}

int ht_set_entry(PMEMobjpool *pop, uint64_t key, char* value) {
    int index = hash_key(key, currcapacity);
    int i,j,n;
    TOID(pmem_ht) root = POBJ_ROOT(pop, pmem_ht);
    printf("Add to persistent mmy\n");

    TX_BEGIN(pop) {
        TX_ADD(root);
        while(D_RO(D_RO(root)->entries[index])->isval != 0) {
            if(key == D_RO(D_RO(root)->entries[index])->key) {
                strcpy(D_RW(D_RW(root)->entries[index])->value, value);
                break;
            }

            index++;
            if(index >= currcapacity) {
                index = 0;
            }
        }
        D_RW(root)->length++;
        D_RW(D_RW(root)->entries[i])->key = key;
        strcpy(D_RW(D_RW(root)->entries[i])->value, value);
        printf("Key:%lu Value:%s\n",
            D_RO(D_RO(root)->entries[i])->key,D_RO(D_RO(root)->entries[i])->value);
    } TX_END
    return 1;
}

int ht_set(PMEMobjpool *pop, uint64_t key, char* value) {
    if(value == NULL) {
        return NULL;
    }

    TOID(pmem_ht) root = POBJ_ROOT(pop, pmem_ht);
    return ht_set_entry(pop, key, value);
}

void printhash(PMEMobjpool *pop){
    TOID(pmem_ht) root = POBJ_ROOT(pop, pmem_ht);
    int idx;

    TX_BEGIN(pop) {
        TX_ADD(root);
        printf("Capacity %lu\t Length:%d\n", D_RO(root)->capacity, D_RO(root)->length);
        idx = 0;
        while(idx < D_RO(root)->capacity) {
            if(D_RO(D_RO(root)->entries[idx])->isval){
                printf("Idx: %d\t IsVal:%d\t Key:%lu\t Value:%s\n", 
                    idx, D_RO(D_RO(root)->entries[idx])->isval, 
                    D_RO(D_RO(root)->entries[idx])->key, D_RO(D_RO(root)->entries[idx])->value);
            }
            idx++;      
        }    
    } TX_END
}

int main(int argc, char *argv[]){
    int ch,f=0;
    uint64_t key; 
    char val[64000], *gval;
    PMEMobjpool *pop;
    TOID(pmem_ht) pershash;

    pop = pmemobj_open(FILE_NAME, LAYOUT_NAME); 
    if(pop == NULL){        
        pop = pmemobj_create(FILE_NAME, LAYOUT_NAME, PMEMOBJ_MIN_POOL, 0666);
        ht_create(pop);
    }
    pershash = POBJ_ROOT(pop, pmem_ht);
    TX_BEGIN(pop) {
        TX_ADD(pershash);
        currcapacity = D_RO(pershash)->capacity;
    } TX_END  

    while(1){
        printf("1-insert 2-retrieve 3-print hashtable 4-quit\n");
        scanf("%d",&ch);
        if(ch==1){
            printf("enter key:\t");
            scanf("%lu", &key);
            printf("enter value:\t");
            scanf("%s", val);            
            ht_set(pop, key, val);
            printf("key %lu val %s stored!\n",key,val);
        }
        else if(ch==2){
            printf("enter key\t");
            scanf("%lu", &key);
            ht_get(pop, key);            
        }
        else if(ch==3){
            printhash(pop);
        }
        else if(ch==4){            
            break;
        }
        else{
            printf("Invalid command\n");
        }
    }

    return 1;
}
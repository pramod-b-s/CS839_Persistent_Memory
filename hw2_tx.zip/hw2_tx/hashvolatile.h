#include <stdbool.h>
#include <stddef.h>

typedef struct ht ht;

size_t ht_length(ht* table);

typedef struct {
    char* key;
    char* value;

    ht* tableitr;
    size_t indexitr;
}hti;

hti ht_iterator(ht* table);

bool ht_next(hti* it);
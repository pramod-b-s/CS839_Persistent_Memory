#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <libpmemobj.h>

#define LAYOUT_NAME "my_persistent_hash"
#define FILE_NAME "myhash"
#define MAX_VAL_LEN 64000

#define INITIAL_CAPACITY 256 

struct ht_entry{
    int isval;
    int idx;
    uint64_t key; 
    char value[64000];
};
typedef struct ht_entry ht_entry;

struct ht {
    ht_entry* entries;
    int capacity;
    int length;
};
typedef struct ht ht;

struct pmem_ht{
    TOID(ht_entry) *entries;
    int capacity;
    int length;
};
typedef struct pmem_ht pmem_ht;


POBJ_LAYOUT_BEGIN(hashcalc);
POBJ_LAYOUT_ROOT(hashcalc, pmem_ht);
POBJ_LAYOUT_TOID(hashcalc, ht_entry);
POBJ_LAYOUT_END(hashcalc);

static int hash_key(uint64_t key, int capacity, int length){
    srand(time(0));
    uint32_t a = rand();
    uint32_t b = rand();
    uint64_t p = rand();

    return ((a*length+b)%p)%capacity;
}

ht* ht_create() {
    ht* table = (ht*)malloc(sizeof(ht));
    if(table == NULL) {
        return NULL;
    }
    table->length = 0;
    table->capacity = INITIAL_CAPACITY;

    table->entries = malloc(table->capacity*sizeof(ht_entry));
    if(table->entries == NULL) {
        free(table);
        return NULL;
    }
    return table;
}

void ht_destroy(ht* table) {
    for(int i = 0; i < table->capacity; i++) {
        if(table->entries[i].key != NULL) {
            free((void*)table->entries[i].key);
        }
    }

    free(table->entries);
    free(table);
}

void ht_get(ht* table, char* key) {
    int index = hash_key(key, table->capacity, table->length);

    while(table->entries[index].isval != 0) {
        if(strcmp(key, table->entries[index].key) == 0) {
            printf("idx: %d\t key: %lu\t key1: %s\t value: %s\n", index, key, table->entries[index].key, table->entries[index].value);
            return;
        }
        else{
            index++;
        }

        if(index >= table->capacity) {
            index = 0;
        }
    }
    printf("entry not found\n");
}

int ht_set_entry(ht_entry* entries, int capacity, uint64_t key, char* value, int *plength) {
    int index = hash_key(key, capacity, 0);
    printf("1");
    while(entries[index].isval != 0) {
        if(key == entries[index].key) {
            strcpy(entries[index].value, value);
            return 0;
        }

        index++;
        if(index >= capacity) {
            index = 0;
        }
    }
    printf("1");
    (*plength)++;    
    entries[index].isval = 1;
    entries[index].idx = index;
    entries[index].key = key;
    strcpy(entries[index].value, value);
    return 1;
}

bool ht_expand(ht* table) {
    int new_capacity = table->capacity * 2;
    ht_entry* new_entries = malloc(new_capacity*sizeof(ht_entry));
    if(new_entries == NULL) {
        printf("memory allocation failed!\n");
        return false;
    }

    for(int i = 0; i < table->capacity; i++) {
        ht_entry entry = table->entries[i];
        ht_set_entry(new_entries, new_capacity, entry.key, entry.value, NULL);        
    }

    free(table->entries);
    table->entries = new_entries;
    table->capacity = new_capacity;
    return true;
}

int ht_set(ht* table, uint64_t key, char* value) {
    if(value == NULL) {
        return NULL;
    }
    if(table->length >= table->capacity / 2) {
        if(!ht_expand(table)) {
            printf("couldn't expand table\n");
            return 0;
        }
    }

    return ht_set_entry(table->entries, table->capacity, key, value, &table->length);
}

void printhash(ht *htable){        
    int idx = 0;
    char *str = NULL;
    while(idx < htable->capacity) {
        if(htable->entries[idx].isval){
            printf("Key:%lu\t Value:%s\n", htable->entries[idx].key, htable->entries[idx].value);
        }
        idx++;      
    }
}

void init_pers_hash(PMEMobjpool *pop, ht *htable){
    TOID(pmem_ht) root;

    TX_BEGIN(pop) {
        TX_ADD(root);
        root = TX_NEW(pmem_ht);
        D_RW(root)->capacity = 0;
        D_RW(root)->length = 0;
        printf("%d %d\n",D_RO(root)->capacity,D_RO(root)->length);
        for(int i=0;i<htable->capacity;i++){
            D_RW(root)->entries[i] = TX_ZALLOC(ht_entry, sizeof(ht_entry));
            //TOID(ht_entry) pershtentry = D_RO(root)->entries[i];
            //printf("%lu %s\n",D_RO(pershtentry)->key,D_RO(pershtentry)->value);
        }
    } TX_END
}

void load_from_pers_mmy(PMEMobjpool *pop, ht *htable){
    int i,j,n;
    TOID(pmem_ht) pershash = POBJ_ROOT(pop, pmem_ht);
    printf("Load from pers mmy\n");
    printf("%d %d\n",D_RO(pershash)->length,D_RO(pershash)->capacity);

    POBJ_FOREACH_TYPE(pop, pershash) {              
        if(D_RO(pershash)->length > 0){
            htable->capacity = D_RO(pershash)->capacity;
            htable->length = D_RO(pershash)->length;
            printf("%d %d\n",D_RO(pershash)->length,D_RO(pershash)->capacity);
            n = D_RO(pershash)->capacity;
            for(i=0;i<n;i++){
                TOID(ht_entry) pershtentry = D_RO(pershash)->entries[i]; 
                printf("%s %s\n",D_RO(pershtentry)->key,D_RO(pershtentry)->value);
                htable->entries[i].key = D_RO(pershtentry)->key;
                n=strlen(htable->entries[i].value);
                for(j=0;j<n;j++){htable->entries[i].value[j] = D_RO(pershtentry)->value[j];}
                htable->entries[i].value[j] = '\0';
            }
        }               
    }
}

void add_to_persist_mmy(PMEMobjpool *pop, ht *htable, int f){
    int i,j,n;
    TOID(pmem_ht) pershash;
    TOID(pmem_ht) root = POBJ_ROOT(pop, pmem_ht);
    printf("Add to pers mmy\n");

    TX_BEGIN(pop) {
        TX_ADD(root);
        if(!f){
            pershash = TX_NEW(pmem_ht);
        }
        else{
            pershash = root;
        }
        D_RW(pershash)->length = htable->length;
        D_RW(pershash)->capacity = htable->capacity;
        printf("%d %d\n",htable->length,htable->capacity);
        
        n=htable->capacity;
        for(i=0;i<n;i++){
            TOID(ht_entry) pershtentry = D_RO(pershash)->entries[i];
            if(htable->entries[i].isval){
                /*printf("%lu %s\n",D_RO(pershtentry)->key,D_RO(pershtentry)->value);
                D_RW(pershtentry)->key=htable->entries[i].key;
                n=strlen(htable->entries[i].value);
                for(j=0;j<n;j++){D_RW(pershtentry)->value[j] = htable->entries[i].value[j];}
                D_RW(pershtentry)->value[j] = '\0';*/
            }
        }
    } TX_END
}

int main(int argc, char *argv[]){
    int ch,f=0;
    uint64_t key; 
    char val[64000], *gval;
    ht *htable;
    PMEMobjpool *pop;
    TOID(pmem_ht) pershash;

    pop = pmemobj_open(FILE_NAME, LAYOUT_NAME); 
    if(pop == NULL){
        pop = pmemobj_create(FILE_NAME, LAYOUT_NAME, PMEMOBJ_MIN_POOL, 0666);                   
        htable = ht_create();
        init_pers_hash(pop, htable);
    }
    else{
        pershash = POBJ_ROOT(pop, pmem_ht);
        //f=1;
        load_from_pers_mmy(pop, htable);
    }    

    if(htable == NULL){
        printf("error creating hashtable\n");
        return 0;     
    }

    while(1){
        printf("1-insert 2-retrieve 3-print hashtable 4-quit\n");
        scanf("%d",&ch);
        if(ch==1){
            printf("enter key:\t");
            scanf("%lu", &key);
            printf("enter value:\t");
            scanf("%s", val);            
            ht_set(htable, key, val);
            printf("key %lu val %s stored!\n",key,val);
        }
        else if(ch==2){
            printf("enter key\t");
            scanf("%lu", &key);
            ht_get(htable, key);            
        }
        else if(ch==3){
            printhash(htable);
        }
        else if(ch==4){
            //add persist code here
            break;
        }
        else{
            printf("Invalid command\n");
        }
    }
    add_to_persist_mmy(pop, htable, 1);

    return 1;
}
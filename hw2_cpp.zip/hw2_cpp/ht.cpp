#include <unistd.h>
#include <libpmemobj.h>
#include <libpmemobj++/transaction.hpp>
#include <libpmemobj++/make_persistent.hpp>
#include <libpmemobj++/p.hpp>
#include <libpmemobj++/persistent_ptr.hpp>
#include <libpmemobj++/pool.hpp>
#include <libpmemobj++/container/string.hpp>

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#define PATH "myhash"


using string_type = pmem::obj::string;
typedef struct hash_entry {
	void initentry(int k) {
		key = k;
		isval = 1;
	}

	pmem::obj::p<int> key;
	pmem::obj::p<int> isval;
	pmem::obj::persistent_ptr<pmem::obj::string> value;
} hash_entry;

using vector_type = pmem::obj::vector<hash_entry>;
typedef struct hash_table {
	hash_table(int capacity1, int length1) {
		capacity = capacity1;
		length = length1;
	}

	void display() {
	}

	pmem::obj::p<int> capacity;
	pmem::obj::p<int> length;
	pmem::obj::persistent_ptr<vector_type> entries;
} hash_table;

struct root {
	pmem::obj::persistent_ptr<hash_table> hashtable;
};

int main(int argc,char *argv[]){
	pmem::obj::pool<root> pop;
	int f = 0;	
	int ch,i,n,key;
	std::string val;
	hash_entry hentry;

	if (access(PATH, F_OK) != 0) {
		pop = pmem::obj::pool<root>::create(PATH, "some_layout", PMEMOBJ_MIN_POOL);		
		auto r1 = pop.root();

		pmem::obj::transaction::run(pop, [&]{
			r1->hashtable = pmem::obj::make_persistent<hash_table>(256,0);
		});
		pmem::obj::transaction::run(pop, [&]{		
			(r1->hashtable)->entries = pmem::obj::make_persistent<vector_type>();
			vector_type &pvector = *((r1->hashtable)->entries);
			char t[100];
			strcpy(t,"--");
			for(i=0;i<256;i++){				
				hentry.initentry(i);
				auto t1 = pmem::obj::make_persistent<string_type>(t, strlen(t));
				pvector.push_back(hentry);
				pvector[i].value=t1;
			}
		});
		std::cout<<"Created persistent memory\n";
		
		f = 1;
	}
	else {
		pop = pmem::obj::pool<root>::open(PATH, "some_layout");
	}

	auto r = pop.root();

	while(1){
		std::cout<<"1-Get k,v\t2-Put k,v\t3-Display k,v\t4-Quit\n";
		std::cin>>ch;

		if(ch==1){
		}
		else if(ch==2){
			std::cout<<"enter key value\t";
			std::cin>>key>>val;
			pmem::obj::transaction::run(pop, [&]{
				vector_type &pvector = *((r->hashtable)->entries);
				for(i=250;i<256;i++){
					pvector[i].isval*=2;
					pvector[i].key*=2;
					std::cout<<pvector[i].isval<<" "<<pvector[i].key<<"\n";	
					// std::string tmp=pvector[i].value;
					// std::cout<<*(pvector[i].value)<<"\n";
				}
			});
		}
		else if(ch==3){
			std::cout<<"Key-Value\n";			
			std::cout<<(r->hashtable)->capacity<<" "<<(r->hashtable)->length<<"\n";
			vector_type &pvector = *((r->hashtable)->entries);
			for(i=0;i<pvector.size();i++){
				std::string t2;
				t2 = std::string(pvector[i].value->c_str(),pvector[i].value->size());
				std::cout<<"begin: "<<pvector[i].isval<<" "<<pvector[i].key<<" Value:"<<t2<<"\n";
			}
		}
		else if(ch==4){
			break;
		}
		else{
			std::cout<<"error\n";
		}
	}

	return 1;	
}